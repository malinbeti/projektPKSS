<?php 
$czas 	= file_get_contents('./czas.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$czas 	= explode(PHP_EOL,$czas);

$ster 	= file_get_contents('./ster.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$ster 	= explode(PHP_EOL,$ster);

$Tp 	= file_get_contents('./Tp.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$Tp 	= explode(PHP_EOL,$Tp);

$ster 	= str_replace(",",".",$ster);
$Tp 	= str_replace(",",".",$Tp);

// var czas 	=  echo json_encode($czas);;
// var ster 	=  echo json_encode($ster); ;
// var Tp 		=  echo json_encode($Tp); 	 ;
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Panel sterowania i kontroli systemu regulacji CO</title>
<style>

div.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
}


div.tab button, .input-bar button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
}


div.tab button:hover, .input-bar button:hover {
    background-color: #ddd;
}


div.tab button.active, .input-bar button:hover {
    background-color: #ccc;
}


.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}

.inputs {
	margin: 10px;
	text-align: center;
}
button.tablinks.update,button.tablinks.change {
	background-color: #949494;
}

.input-bar {
	height: 43px;   
	margin-left: 465px;
}
button#updateBtn,.input-bar-sgl {
    width: 235px;
}

.input-bar-sgl,.input-bar-btn {
	background-color: #f1f1f1;
	float:left;
	text-align: center;
}

button.change, button.update {
	width: 120px;
}

</style>

</head>
<body>

<div class="tab">
	<button class="tablinks" onclick="openCity(event, 'elektro')" id="defaultOpen">Elektrociepłownia</button>
	<button class="tablinks" onclick="openCity(event, 'wymiennik')">Wymiennik ciepła</button>
	<button class="tablinks" onclick="openCity(event, 'budynek')">Charakterystyka budynków</button>
	
	<button id="ToBtn" class="updateBtn tablinks" >Temperatura otoczenia (20.1 &deg)</button>
	<button id="Tr1zadBtn" class="updateBtn tablinks" >Temperatura w budynku 1 (20.2 &deg)</button>
	<button id="Tr2zadBtn" class="updateBtn tablinks" >Temperatura w budynku 2 (20.3 &deg)</button>
  
	<button id="change" class="tablinks change" onclick="displayInputs()">Zmień</button>
	<button style="display:none" id="update" class="tablinks update" onclick="updateTempBtn()">Aktualizuj</button>
</div>


<div style="display:none" class="input-bar">
	<div class="input-bar-sgl">
		<input type="number" name="To" 	min="-50" value="0" max="50" step="0.1" class="tablinks inputs" id="To"	onkeyup="handleChange(this,1);"	onfocus="this.value=''" required>
	</div>
	<div class="input-bar-sgl">
		<input type="number" name="Tr1zad" 	min="0" value="0"max="30" step="0.1" class="tablinks inputs" id="Tr1zad" onkeyup="handleChange(this,2);" onfocus="this.value=''" required>
	</div>
	<div class="input-bar-sgl">
		<input type="number" name="Tr2zad" 	min="0" value="0"max="30" step="0.1" class="tablinks inputs" id="Tr2zad" onkeyup="handleChange(this,2);" onfocus="this.value=''" required>
	</div>
</div>

<div id="elektro" class="tabcontent" style="">
 <div id="elektrocieplownia" style="width: 100%;display: inline-block;height:100%"></div>
</div>


<div id="wymiennik" class="tabcontent" style="">
<div id="wymiennik_temp" style="width: 100%;display: inline-block;height:50%"></div>
<div id="wymiennik_strum" style="width: 100%;display: inline-block;height:50%"></div>
</div>

<div id="budynek" class="tabcontent" style="">
<div id="budynek_temp"  style="display: inline-block;width:48%;height:50%"></div>
<div id="budynek_ster1" style="display: inline-block;width:48%;height:50%"></div>
<div id="budynek_ster2" style="display: inline-block;width:48%;height:50%"></div>
<div id="budynek_wym"   style="display: inline-block;width:48%;height:50%"></div>
</div>


<script type="text/javascript" src="lib/js/canvasjs.min.js"></script>
<script>

function getValueFromDB() {
	
	//polaczenie z baza - pobranie danych do wykresow
}

function getSetValueTemp(To,Tr1zad,Tr2zad) {
	
	//polaczenie z baza - pobranie wartosci zadanych
	// console.log(document.getElementById("To").innerText);
	
	document.getElementById("ToBtn").innerText = "Temperatura otoczenia ("+ To + String.fromCharCode(176) + ")";
	document.getElementById("Tr1zadBtn").innerText = "Temperatura w budynku 1 ("+ Tr1zad + String.fromCharCode(176) + ")";
	document.getElementById("Tr2zadBtn").innerText = "Temperatura w budynku 2 ("+ Tr2zad + String.fromCharCode(176) + ")";
}


function updateTempBtn() {
	console.log("temp");
	
	var inputs = document.getElementsByClassName( 'inputs' );

	
	console.log(inputs[0].value);
	// console.log(names);
	
	//polaczenie z baza - aktualizacja danych =>zapis
	getSetValueTemp(20,30,10);
}

function displayInputs(){
	console.log("display");
	document.getElementById("change").style.display = "none";
	document.getElementById("update").style.display = "block";
	document.getElementsByClassName("input-bar")[0].style.display = "block";
	
}

document.getElementById("change").onmouseup = function(e) { 
	e.stopPropagation();
};

document.getElementsByClassName("input-bar")[0].onmouseup = function(e) { 
	e.stopPropagation();
};

document.body.onmouseup = function(e) { 
	document.getElementsByClassName("input-bar")[0].style.display = "none";
	document.getElementById("update").style.display = "none";
	document.getElementById("change").style.display = "block";
};

document.getElementById("defaultOpen").click();

function resize() {
	var heights = window.innerHeight;
	document.getElementById("elektro").style.height = heights -75 + "px";
	document.getElementById("wymiennik").style.height = heights -75 + "px";
	document.getElementById("budynek").style.height = heights -75 + "px";
}

function handleChange(input,type) {
	
	
	if(parseInt(type) == 1){
		
		if (input.value < -50 ) 
		{
			input.value = -50;
			
		}else if (input.value > 50)
		{		
			input.value = 50;
		}else{
			//input.value = parseInt(input.value);
		}
	}
	
	
	if(parseInt(type) == 2){
		if (input.value < 0 || isNaN(input.value)) 
		{
			input.value = 0;
			
		}else if (input.value > 30)
		{		
			input.value = 30;
		}else{
			//input.value = parseInt(input.value);
		}
	}
	
 }


resize();

window.onresize = function() {
	resize();
};


var Tzm = [
{ x: new Date(2014, 00, 01), y: 40 },
{ x: new Date(2014, 01, 01), y: 41 },
{ x: new Date(2014, 02, 01), y: 41 },
{ x: new Date(2014, 03, 01), y: 42 },
{ x: new Date(2014, 04, 01), y: 42 },
{ x: new Date(2014, 05, 01), y: 40 },
{ x: new Date(2014, 06, 01), y: 40 },
{ x: new Date(2014, 07, 01), y: 45 },
{ x: new Date(2014, 08, 01), y: 45 },
{ x: new Date(2014, 09, 01), y: 40 },
{ x: new Date(2014, 10, 01), y: 40 },
{ x: new Date(2014, 11, 01), y: 49 },
{ x: new Date(2015, 00, 01), y: 45 },
{ x: new Date(2015, 01, 01), y: 40 },
{ x: new Date(2015, 02, 01), y: 45 },
{ x: new Date(2015, 03, 01), y: 45 },
{ x: new Date(2015, 04, 01), y: 45 },
{ x: new Date(2015, 05, 01), y: 49 },
{ x: new Date(2015, 06, 01), y: 45 },
{ x: new Date(2015, 07, 01), y: 49 },
{ x: new Date(2015, 08, 01), y: 50 },
{ x: new Date(2015, 09, 01), y: 50 },
{ x: new Date(2015, 10, 01), y: 52 },
{ x: new Date(2015, 11, 01), y: 55 },
{ x: new Date(2016, 00, 01), y: 55 },
{ x: new Date(2016, 01, 01), y: 59 },
{ x: new Date(2016, 02, 01), y: 59 },
{ x: new Date(2016, 03, 01), y: 55 },
{ x: new Date(2016, 04, 01), y: 58 },
{ x: new Date(2016, 05, 01), y: 55 },
{ x: new Date(2016, 06, 01), y: 57 },
{ x: new Date(2016, 07, 01), y: 55 },
{ x: new Date(2016, 08, 01), y: 55 },
{ x: new Date(2016, 09, 01), y: 59 },
{ x: new Date(2016, 10, 01), y: 55 },
{ x: new Date(2016, 11, 01), y: 55 },
{ x: new Date(2017, 00, 01), y: 59 },
{ x: new Date(2017, 01, 01), y: 60 },
{ x: new Date(2017, 02, 01), y: 62 },
{ x: new Date(2017, 03, 01), y: 65 },
{ x: new Date(2017, 04, 01), y: 65 },
{ x: new Date(2017, 05, 01), y: 67 }];

var F = [
{ x: new Date(2015, 05, 01), y: 9 },
{ x: new Date(2015, 06, 01), y: 9 },
{ x: new Date(2015, 07, 01), y: 9 },
{ x: new Date(2015, 08, 01), y: 10 },
{ x: new Date(2015, 09, 01), y: 17 },
{ x: new Date(2015, 10, 01), y: 15 },
{ x: new Date(2015, 11, 01), y: 10 },
{ x: new Date(2016, 00, 01), y: 9 },
{ x: new Date(2016, 01, 01), y: 1 },
{ x: new Date(2016, 02, 01), y: 11 },
{ x: new Date(2016, 03, 01), y: 15 },
{ x: new Date(2016, 04, 01), y: 11 },
{ x: new Date(2016, 05, 01), y: 11 },
{ x: new Date(2016, 06, 01), y: 10 },
{ x: new Date(2016, 07, 01), y: 10 },
{ x: new Date(2016, 08, 01), y: 11 },
{ x: new Date(2016, 09, 01), y: 11 },
{ x: new Date(2016, 10, 01), y: 15 },
{ x: new Date(2016, 11, 01), y: 15 },
{ x: new Date(2017, 00, 01), y: 15 },
{ x: new Date(2017, 01, 01), y: 12 },
{ x: new Date(2017, 02, 01), y: 12 },
{ x: new Date(2017, 03, 01), y: 12 },
{ x: new Date(2017, 04, 01), y: 19 },
{ x: new Date(2017, 05, 01), y: 17 }];

var Fzm = Tzm;
var Fcob1 = F;
var Fcob2 = F;
var Tzco = Tzm;
var Tpcob1 = Tzm;
var Tpcob2 = Tzm;
var Tr1 = F;
var Tr2 = F;
var Ub1 = Tzm;
var Ub2 = Tzm;
var Um = Tzm;
	
var x_title = "Czas []";
var title_size = 30;
var axis_size = 20;

////////////////////////////////////////////////////////////////////////
var options1_elektro = {
	animationEnabled: true,
	zoomEnabled: true,
	title: {
		text: "Parametry pochodzące z elektrociepłowni",
		fontSize: title_size
	},
	axisX: {
		title: x_title,
		titleFontSize: axis_size
	},
	axisY: {
		title: "Temperatura ["+ String.fromCharCode(176) +"C]",
		titleFontColor: "#4F81BC",
		// suffix : " 9&#176; ",
		lineColor: "#4F81BC",
		tickColor: "#4F81BC",
		titleFontSize: axis_size,
		minimum: 70,
		maximum: 135
	},
	axisY2: {
		title: "Strumień [t/h]",
		titleFontColor: "#C0504E",
		// suffix : " m",
		lineColor: "#C0504E",
		tickColor: "#C0504E",
		titleFontSize: axis_size,
		minimum: 0,
		maximum: 80
	}, 
	toolTip: {
		shared: true
	},
	legend: {
		cursor:"pointer",
		verticalAlign: "top",
		fontColor: "dimGrey",
		fontSize: 14,
		itemclick : toggleDataSeries
	},
	data: [{ 
		type: "spline",
		xValueType: "dateTime",
		yValueFormatString: "####.00",
		xValueFormatString: "hh TT",
		showInLegend: true,
		name: "Temperatura wody zasilającej z elektrociepłowni",
		dataPoints: Tzm
		},
		{				
			type: "spline",
			axisYType: "secondary",
			xValueType: "dateTime",
			yValueFormatString: "####.00",
			showInLegend: true,
			name: "Strumień wody wypływającej z elektrociepłowni" ,
			dataPoints: Fzm
	}]
};

///////////////////////////////////////////////////////////////////////////////
var options1_wym_strum = {
	animationEnabled: true,
	zoomEnabled: true,
	title: {
		text: "Strumienie wody wpływające do budynków",
		fontSize: title_size
	},
	axisX: {
		title: x_title,
		titleFontSize: axis_size
	},
	axisY: {
		title: "Strumień [t/h]",
		titleFontSize: axis_size,
		minimum: 0,
		maximum: 40
	}, 
	toolTip: {
		shared: true
	},
	legend: {
		cursor:"pointer",
		verticalAlign: "top",
		fontSize: 14,
		fontColor: "dimGrey",
		itemclick : toggleDataSeries
	},
	data: [{ 
		type: "spline",
		xValueType: "dateTime",
		yValueFormatString: "####.00",
		xValueFormatString: "hh TT",
		showInLegend: true,
		name: "Strumień wody wpływający do budynku 1",
		dataPoints: Fcob1
		},
		{				
			type: "spline",
			xValueType: "dateTime",
			yValueFormatString: "####.00",
			showInLegend: true,
			name: "Strumień wody wpływający do budynku 2" ,
			dataPoints: Fcob2
		}]
};
//////////////////////////////////
var options2_wym_temp = {
	animationEnabled: true,
	zoomEnabled: true,
	title: {
		text: "Temperatura wody krążącej w lokalej sieci CO",
		fontSize: title_size
	},
	axisX: {
		title: x_title,
		titleFontSize: axis_size
	},
	axisY: {
		title: "Temperatura ["+ String.fromCharCode(176) +"C]",
		titleFontSize: axis_size,
		minimum: 0,
		maximum: 135
	}, 
	toolTip: {
		shared: true
	},
	legend: {
		cursor:"pointer",
		verticalAlign: "top",
		fontSize: 14,
		fontColor: "dimGrey",
		itemclick : toggleDataSeries
	},
	data: [{ 
		type: "spline",
		xValueType: "dateTime",
		yValueFormatString: "####.00",
		xValueFormatString: "hh TT",
		showInLegend: true,
		name: "Temperatura wody wpływającej do budynków",
		dataPoints: Tzco
		},
		{				
		type: "spline",
		xValueType: "dateTime",
		yValueFormatString: "####.00",
		showInLegend: true,
			name: "Temperatura wody wypływającej z budynku 1" ,
		dataPoints: Tpcob1
		},
			{				
			type: "spline",
			xValueType: "dateTime",
			yValueFormatString: "####.00",
			showInLegend: true,
			name: "Strumień wody wpływający do budynku 2" ,
			dataPoints: Tpcob2
		}]
};

///////////////////////////////////////////////////////////////////////////////
var options1_bud = {
	animationEnabled: true,
	zoomEnabled: true,
	title: {
		text: "Temperatura w budynkach",
		fontSize: title_size
	},
	axisX: {
		title: x_title,
		titleFontSize: axis_size
	},
	axisY: {
		title: "Temperatura ["+ String.fromCharCode(176) +"C]",
		titleFontSize: axis_size,
		minimum: 0,
		maximum: 30
	}, 
	// toolTip: {
		// shared: true
	// },
	legend: {
		cursor:"pointer",
		verticalAlign: "top",
		fontColor: "dimGrey",
		fontSize: 14,
		itemclick : toggleDataSeries
	},
	data: [{ 
		type: "spline",
		xValueType: "dateTime",
		//yValueFormatString: "####.00",
		xValueFormatString: "hh TT",
		showInLegend: true,
		name: "Uśredniona temperatura pomieszczeń w budynku 1",
		dataPoints: Tr1
		},
		{				
		type: "spline",
		xValueType: "dateTime",
		// yValueFormatString: "####.00",
		showInLegend: true,
			name: "Uśredniona temperatura pomieszczeń w budynku 2" ,
		dataPoints: Tr2
		}]
};
////////////////////////////////////
var options2_bud_ster1 = {
	animationEnabled: true,
	zoomEnabled: true,
	title: {
		text: "Sygnał sterujący zaworem w budynku 1",
		fontSize: title_size
	},
	axisX: {
		title: x_title,
		titleFontSize: axis_size
	},
	axisY: {
		title: "Napięcie [V]",
		titleFontSize: axis_size,
		minimum: 20,
		maximum: 60
	}, 
	// toolTip: {
		// shared: true
	// },
	legend: {
		cursor:"pointer",
		verticalAlign: "top",
		fontSize: 14,
		fontColor: "dimGrey",
		itemclick : toggleDataSeries
	},
	data: [{ 
		type: "spline",
		xValueType: "dateTime",
		//yValueFormatString: "####.00",
		xValueFormatString: "hh TT",
		showInLegend: true,
		name: "Sygnał sterujący generowany przez regulator zaworu budynku 1",
		dataPoints: Ub1
		}]
};

///////////////////////////////////
var options2_bud_ster2 = {
	animationEnabled: true,
	zoomEnabled: true,
	title: {
		text: "Sygnał sterujący zaworem w budynku 2",
		fontSize: title_size
	},
	axisX: {
		title: x_title,
		titleFontSize: axis_size
	},
	axisY: {
		title: "Napięcie [V]",
		titleFontSize: axis_size,
		minimum: 20,
		maximum: 60
	}, 
	// toolTip: {
		// shared: true
	// },
	legend: {
		cursor:"pointer",
		verticalAlign: "top",
		fontSize: 14,
		fontColor: "dimGrey",
		itemclick : toggleDataSeries
	},
	data: [{ 
		type: "spline",
		xValueType: "dateTime",
		//yValueFormatString: "####.00",
		xValueFormatString: "hh TT",
		showInLegend: true,
		name: "Sygnał sterujący generowany przez regulator zaworu budynku 2",
		dataPoints: Ub2
		}]
};

///////////////////////////////////
var options2_bud_ster3 = {
	animationEnabled: true,
	zoomEnabled: true,
	title: {
		text: "Sygnał sterujący zaworem w wymienniku ciepła",
		fontSize: title_size
	},
	axisX: {
		title: x_title,
		titleFontSize: axis_size
	},
	axisY: {
		titleFontSize: axis_size,
		title: "Napięcie [V]",
		minimum: 20,
		maximum: 60
	}, 
	// toolTip: {
		// shared: true
	// },
	legend: {
		cursor:"pointer",
		verticalAlign: "top",
		fontSize: 14,
		fontColor: "dimGrey",
		itemclick : toggleDataSeries
	},
	data: [{ 
		type: "spline",
		xValueType: "dateTime",
		//yValueFormatString: "####.00",
		xValueFormatString: "hh TT",
		showInLegend: true,
		name: "Sygnał sterujący generowany przez regulator zaworu wymiennika ciepła",
		dataPoints: Um
		}]
};
///////////////////////////////////////////////////////////////////////////////

//Render Charts after tabs have been created.
renderChart();


function toggleDataSeries(e) {
	if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	}
	else {
		e.dataSeries.visible = true;
	}
	chart.render();
}
function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
	
	renderChart();
}

function renderChart() {
	var chart1 = new CanvasJS.Chart("elektrocieplownia",options1_elektro);
	chart1.render();

	var chart2 = new CanvasJS.Chart("wymiennik_temp",options2_wym_temp);
	chart2.render();

	var chart3 = new CanvasJS.Chart("wymiennik_strum",options1_wym_strum);
	chart3.render();

	var chart4 = new CanvasJS.Chart("budynek_temp",options1_bud);
	chart4.render();

	var chart5 = new CanvasJS.Chart("budynek_ster1",options2_bud_ster1);
	chart5.render();

	var chart6 = new CanvasJS.Chart("budynek_ster2",options2_bud_ster2);
	chart6.render();

	var chart7 = new CanvasJS.Chart("budynek_wym",options2_bud_ster3);
	chart7.render();
}

function updateTemp() {
}

</script>
</body>
</html>